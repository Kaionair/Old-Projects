#Nerdy Setup Stuff
import pygame, sys, random
from pygame.locals import QUIT
pygame.init()
pygame.font.init()
window = pygame.display.set_mode((500, 300))
pygame.display.set_caption('Hypostatic Symphony')
#Setting Up Variables and Images
inazuma = pygame.image.load('Inazuma_Card_Box.png')
inazuma = pygame.transform.scale(inazuma, (700,420))
liyue = pygame.image.load('Liyue_Card_Box.png')
liyue = pygame.transform.scale(liyue, (700,420))
sumeru = pygame.image.load('Sumeru_Card_Box.png')
sumeru = pygame.transform.scale(sumeru, (700,420))
electro_bg = pygame.image.load('electro-hypostasis.png')
electro_bg = pygame.transform.scale(electro_bg, (500,300))
play = pygame.image.load('Play.png')
play = pygame.transform.scale(play, (100,25))
rules = pygame.image.load('Rules.png')
rules = pygame.transform.scale(rules, (100,25))
exit = pygame.image.load('Exit.png')
exit = pygame.transform.scale(exit, (100,25))
play_a = pygame.image.load('Play Again.png')
play_a = pygame.transform.scale(play_a, (100,25))
back_to = pygame.image.load('Back_to_Menu.png')
back_to = pygame.transform.scale(back_to, (100,25))
thanks = pygame.image.load('Thanks.png')
thanks = pygame.transform.scale(thanks, (250,250))
controls = pygame.image.load('Controls.png')
controls = pygame.transform.scale(controls, (450,270))
victory = pygame.image.load('Victory.png')
victory = pygame.transform.scale(victory, (250,150))
defeat = pygame.image.load('Defeat.png')
defeat = pygame.transform.scale(defeat, (250,150))
run_game = True
restart_game = False
first_time = True
#THE MENU
def menu_load(first_time):
  pygame.time.delay(300)
  if first_time == True:
    menu = 2
  else:
    menu = 0
  menu_state = 1
  menu_delay = 0
  loop_menu = True
  while loop_menu == True:
    while menu == 0:
      for event in pygame.event.get():
        if event.type == QUIT:
          pygame.quit()
          sys.exit()
      pygame.time.delay(25)
      #Moving Through the Menu
      keys = pygame.key.get_pressed()
      if keys[pygame.K_w] and menu_state > 1 and menu_delay == 0:
        menu_state -= 1
        menu_delay = 5
      if keys[pygame.K_s] and menu_state < 3 and menu_delay == 0: 
        menu_state += 1
        menu_delay = 5
      if keys[pygame.K_SPACE]:
        if menu_state == 1:
          menu = 1
          loop_menu = False
        elif menu_state == 2:
          menu = 2
        else:
          menu = 3
      if menu_delay != 0:
        menu_delay -= 1
      #All the Images
      window.blit(electro_bg,(0,0))
      if menu_state == 1:
        pygame.draw.rect(window, (28, 244, 176), (320,190,100,25))
        pygame.draw.rect(window, (28, 96, 244), (320,225,100,25))
        pygame.draw.rect(window, (28, 96, 244), (320,260,100,25))
      elif menu_state == 2:
        pygame.draw.rect(window, (28, 96, 244), (320,190,100,25))
        pygame.draw.rect(window, (28, 244, 176), (320,225,100,25))
        pygame.draw.rect(window, (28, 96, 244), (320,260,100,25))
      else:
        pygame.draw.rect(window, (28, 96, 244), (320,190,100,25))
        pygame.draw.rect(window, (28, 96, 244), (320,225,100,25))
        pygame.draw.rect(window, (28, 244, 176), (320,260,100,25))
      window.blit(play,(320,190))
      window.blit(rules,(320,225))
      window.blit(exit,(320,260))
      pygame.display.update()
    #Control Menu Loop
    while menu == 2:
      pygame.time.delay(25)
      for event in pygame.event.get():
        if event.type == QUIT:
          pygame.quit()
          sys.exit()
      keys = pygame.key.get_pressed()
      if keys[pygame.K_ESCAPE]:
        menu = 0
      window.blit(inazuma,(-100,-60))
      window.blit(controls,(25,10))
      pygame.display.update()
    while menu == 3:
      pygame.time.delay(25)
      for event in pygame.event.get():
        if event.type == QUIT:
          pygame.quit()
          sys.exit()
      window.blit(inazuma,(-100,-60))
      window.blit(thanks,(125,25))
      pygame.display.update()    

#The GAME
def main_game():
  pygame.time.delay(100)
  #Player Assets
  player_healthbar_y = 30
  player_health = 100
  player_x = 50
  player_y = 190
  player_w = 30
  player_h = 60
  player_d = 0
  player_color = (248, 235, 34)
  attack_cooldown = 0
  blast_cooldown = 0
  hit_cooldown = 0
  #Electro Hypostasis Assets
  electro_health = 400
  electro_x = 400
  electro_savex = 400
  electro_y = 150
  electro_w = 80
  electro_h = 80
  electro_direction = 0
  electro_weak = 0
  electro_cooldown = 50
  electro_current = 0
  electro_record = electro_current
  electro_last = electro_current
  electro_attacks = ['rain','trap','drill','lazer']
  #Rain Assets
  e_rain1_x = random.randint(-10,460)
  e_rain2_x = random.randint(-10,460)
  e_rain3_x = random.randint(-10,460)
  e_rain1_y = -100
  e_rain2_y = -150
  e_rain3_y = -200
  #Trap Assets
  e_pillar1_x = 0
  e_pillar2_x = 0
  e_pillar3_x = 0
  e_pillar4_x = 0
  e_pillar1_y = -150
  e_pillar2_y = -150
  e_pillar3_y = -150
  e_pillar4_y = -150
  #Drill Assets
  drill_L = pygame.image.load('Drill_left.png')
  drill_L = pygame.transform.scale(drill_L, (120,120))
  drill_R = pygame.image.load('Drill_right.png')
  drill_R = pygame.transform.scale(drill_R, (120,120))
  #Lazer Assets
  lazer_x = 600
  lazer_y = 200
  #Other Assets
  blast_reach = 50
  blast_charge = (249, 249, 159)
  sword_reach = 30
  jumpcount = 10
  jumping = False
  while player_health > 0 and electro_health > 0:
    pygame.time.delay(25)
    for event in pygame.event.get():
      if event.type == QUIT:
        pygame.quit()
        sys.exit()
    keys = pygame.key.get_pressed()
  #Stage
    pygame.draw.rect(window, (45, 195, 247), (0,0,500,300))
    pygame.draw.rect(window, (150,150,150), (0,250,500,300))
  #Controls
    if hit_cooldown != 0:
      player_color = (214, 151, 49)
    else:
      player_color = (248, 235, 34)
    if keys[pygame.K_a] and player_x>-10:
      player_x -= 6
      if jumping == False:
        player_w = 50
        player_h = 30
        player_y = 220
        player_d = 0
    if keys[pygame.K_d] and player_x<470:
      player_x += 6
      if jumping == False:
        player_w = 50
        player_h = 30
        player_y = 220
        player_d = 1
    if keys[pygame.K_a]==False and keys[pygame.K_d]==False and jumping==False:
      player_w = 30
      player_h = 60
      player_y = 190
    elif jumping == True:
      player_w = 30
      player_h = 60
    pygame.draw.rect(window,player_color,(player_x,player_y,player_w,player_h))
  #Jumping Code
    if keys[pygame.K_SPACE] and jumping == False:
      jumping = True
      player_y = 190
    if jumping == True:
      if jumpcount >= -10:
        neg = 1
        if jumpcount < 0:
          neg = -1
        player_y -= (jumpcount**2) * 0.25 * neg
        jumpcount -= 1
      else:
        jumping = False
        jumpcount = 10
  #AttackingCode
    if keys[pygame.K_j] and attack_cooldown == 0 and blast_cooldown<=160:
      attack_cooldown = 20
    if attack_cooldown >= 18:
      if player_d == 1:
        pygame.draw.rect(window, (150,150,150), (player_x+player_w,player_y,sword_reach,player_h))
        if player_x+player_w<electro_x+electro_w and player_x+player_w+sword_reach>electro_x:
          if player_y<electro_y+electro_h and player_y+player_h>electro_y:
            if electro_weak != 0:
              electro_health -= 1
      else:
        pygame.draw.rect(window, (150,150,150),(player_x-sword_reach,player_y,sword_reach,player_h))
        if player_x-sword_reach<electro_x+electro_w and player_x>electro_x:
          if player_y<electro_y+electro_h and player_y+player_h>electro_y:
            if electro_weak != 0:
              electro_health -= 1
    if keys[pygame.K_k] and blast_cooldown == 0:
      blast_cooldown = 200
    if blast_cooldown >= 180:
      if player_d == 1:
        pygame.draw.rect(window, (249, 249, 159), (player_x+player_w,player_y,blast_reach,player_h))
        if player_x+player_w<electro_x+electro_w and player_x+player_w+blast_reach>electro_x:
          if player_y<electro_y+electro_h and player_y+player_h>electro_y:
            if electro_weak != 0:
              electro_health -= 1
      else: 
        pygame.draw.rect(window, (249, 249, 159),(player_x-blast_reach,player_y,blast_reach,player_h))
        if player_x-blast_reach<electro_x+electro_w and player_x>electro_x:
          if player_y<electro_y+electro_h and player_y+player_h>electro_y:
            if electro_weak != 0:
              electro_health -= 1
    if hit_cooldown != 0:
      hit_cooldown -=1
    if attack_cooldown != 0:
      attack_cooldown -= 1
    if blast_cooldown != 0:
      blast_cooldown -= 1
      blast_charge = (177, 177, 160)
    else:
      blast_charge = (249, 249, 159)
  #Electro Hypostasis Code
    if electro_cooldown == 0 and electro_weak == 0:
      while electro_record == electro_last:
        electro_current = electro_attacks[random.randint(0,3)]
        electro_record = electro_current
      electro_last = electro_current
    if electro_current == 'rain':
      if electro_cooldown == 0:
        electro_savex = 210
        e_rain1_x = random.randint(-10,460)
        e_rain2_x = random.randint(-10,460)
        e_rain3_x = random.randint(-10,460)
        e_rain1_y = -50
        e_rain2_y = -100
        e_rain3_y = -150
        electro_weak = 750
        electro_cooldown = 800
      elif electro_cooldown >= 450:
        pygame.draw.rect(window, (206, 56, 241), (e_rain1_x, e_rain1_y,50, 50))
        e_rain1_y += 7
        if e_rain1_y >= 210:
          e_rain1_x = random.randint(-10,460)
          e_rain1_y = -100
        pygame.draw.rect(window, (206, 56, 241), (e_rain2_x, e_rain2_y,50, 50))
        e_rain2_y += 7
        if e_rain2_y >= 210:
          e_rain2_x = random.randint(-10,460)
          e_rain2_y = -100
        pygame.draw.rect(window, (206, 56, 241), (e_rain3_x, e_rain3_y,50, 50))
        e_rain3_y += 7
        if e_rain3_y >= 210:
          e_rain3_x = random.randint(-10,460)
          e_rain3_y = -100
      elif electro_cooldown >= 350:
        pygame.draw.rect(window, (206, 56, 241), (e_rain1_x, e_rain1_y,50, 50))
        e_rain1_y += 7
        pygame.draw.rect(window, (206, 56, 241), (e_rain2_x, e_rain2_y,50, 50))
        e_rain2_y += 7
        pygame.draw.rect(window, (206, 56, 241), (e_rain3_x, e_rain3_y,50, 50))
        e_rain3_y += 7
      if e_rain1_x<player_x+player_w and e_rain1_x+50>player_x:
        if e_rain1_y<player_y+player_h and e_rain1_y+50>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 7
            player_health -= 7
            hit_cooldown = 30
      if e_rain2_x<player_x+player_w and e_rain2_x+50>player_x:
        if e_rain2_y<player_y+player_h and e_rain2_y+50>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 7
            player_health -= 7
            hit_cooldown = 30
      if e_rain3_x<player_x+player_w and e_rain3_x+50>player_x:
        if e_rain3_y<player_y+player_h and e_rain3_y+50>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 7
            player_health -= 7
            hit_cooldown = 30
      if electro_cooldown == 350:
        electro_current = 0
        e_rain1_y = -100
        e_rain2_y = -150
        e_rain3_y = -200
    if electro_current == 'trap':
      if electro_cooldown == 0:
        electro_cooldown = 230
        electro_weak = 180
        if player_x <= 250:
          electro_direction = 1
        else:
          electro_direction = 0
        if electro_direction == 0:
          electro_x = 50
          electro_savex = 25
          electro_y = 190
          e_pillar1_x = 120
          e_pillar2_x = 230
          e_pillar3_x = 340
          e_pillar4_x = 450
        elif electro_direction == 1:
          electro_x = 420
          electro_savex = 395
          electro_y = 190
          e_pillar1_x = 360
          e_pillar2_x = 250
          e_pillar3_x = 140
          e_pillar4_x = 30
      if electro_cooldown <= 200 and electro_cooldown > 100:
        if e_pillar1_y <= 100:
          e_pillar1_y += 15
      if electro_cooldown <= 180 and electro_cooldown > 100:
        if e_pillar2_y <= 100:
          e_pillar2_y += 15
      if electro_cooldown <= 160 and electro_cooldown > 100:
        if e_pillar3_y <= 100:
          e_pillar3_y += 15
      if electro_cooldown <= 140 and electro_cooldown > 100:
        if e_pillar4_y <= 100:
          e_pillar4_y += 15
      if electro_cooldown == 100:
        e_pillar1_y = -150
        e_pillar2_y = -150
        e_pillar3_y = -150
        e_pillar4_y = -150
      pygame.draw.rect(window, (206, 56, 241), (e_pillar1_x,e_pillar1_y,20,150))
      pygame.draw.rect(window, (206, 56, 241), (e_pillar2_x,e_pillar2_y,20,150))
      pygame.draw.rect(window, (206, 56, 241), (e_pillar3_x,e_pillar3_y,20,150))
      pygame.draw.rect(window, (206, 56, 241), (e_pillar4_x,e_pillar4_y,20,150))
      if e_pillar1_x<player_x+player_w and e_pillar1_x+20>player_x:
        if e_pillar1_y<player_y+player_h and e_pillar1_y+150>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 10
            player_health -= 10
            hit_cooldown = 30
            if electro_direction == 0:
              player_x += 120
            else:
              player_x -= 120
      if e_pillar2_x<player_x+player_w and e_pillar2_x+20>player_x:
        if e_pillar2_y<player_y+player_h and e_pillar2_y+150>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 10
            player_health -= 10
            hit_cooldown = 30
            if electro_direction == 0:
              player_x += 120
            else:
              player_x -= 120
      if e_pillar3_x<player_x+player_w and e_pillar3_x+20>player_x:
        if e_pillar3_y<player_y+player_h and e_pillar3_y+150>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 10
            player_health -= 10
            hit_cooldown = 30
            if electro_direction == 0:
              player_x += 120
            else:
              player_x -= 120
      if e_pillar4_x<player_x+player_w and e_pillar4_x+20>player_x:
        if e_pillar4_y<player_y+player_h and e_pillar4_y+150>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 10
            player_health -= 10
            hit_cooldown = 30
            if electro_direction == 0:
              player_x += 120
            else:
              player_x -= 120
    if electro_current == 'drill':
      if electro_cooldown == 0:
        electro_cooldown = 200
        electro_y = 140
        if player_x <= 250:
          electro_direction = 1
          electro_x = 400
        else:
          electro_direction = 0
          electro_x = 20
      if electro_cooldown <= 200 and electro_direction == 0:
        if electro_x +20 <player_x+player_w and electro_x+110>player_x:
          if electro_y-20 <player_y+player_h and electro_y+100>player_y:
            if hit_cooldown == 0:
              player_healthbar_y += 20
              player_health -= 20
              hit_cooldown = 30
              player_x += 150
        electro_x += 3
      if electro_cooldown <= 200 and electro_direction == 1:
        if electro_x - 70<player_x+player_w and electro_x+20>player_x:
          if electro_y-20 <player_y+player_h and electro_y+100>player_y:
            if hit_cooldown == 0:
              player_healthbar_y += 20
              player_health -= 20
              hit_cooldown = 30
              player_x -= 150
        electro_x -= 3
      if electro_cooldown == 150:
        electro_x = electro_x + 25
        electro_savex = electro_x-25
        electro_weak = 100
        electro_current = 0 
    if electro_current == 'lazer':
      if electro_cooldown == 0:
        electro_cooldown = 700
        electro_weak = 650
        if player_x <= 250:
          electro_direction = 1
          electro_x = 420
          electro_savex = 395
          lazer_x = 350
          lazer_y = random.randint(150,200)
        else:
          electro_direction = 0
          electro_x = 50
          electro_savex = 25
          lazer_x = 100
          lazer_y = random.randint(150,200)
      if electro_cooldown >= 350 and electro_cooldown<=670:
        if electro_direction == 0:
          lazer_x += 10
          if lazer_x >= 550:
            lazer_y = random.randint(150,200)
            lazer_x = 100
        if electro_direction == 1:
          lazer_x -= 10
          if lazer_x <= -50:
            lazer_y = random.randint(150,200)
            lazer_x = 350
      elif electro_cooldown > 300 and electro_cooldown<=670:
        if electro_direction == 0:
          lazer_x += 10
        if electro_direction == 1:
          lazer_x -= 10
      if electro_cooldown == 300:
        electro_current = 0
        lazer_x = 650
      pygame.draw.rect(window, (206, 56, 241), (lazer_x, lazer_y,50, 50))
      if lazer_x<player_x+player_w and lazer_x+50>player_x:
        if lazer_y<player_y+player_h and lazer_y+50>player_y:
          if hit_cooldown == 0:
            player_healthbar_y += 10
            player_health -= 10
            hit_cooldown = 30
    if electro_weak > 0 and electro_current != 'rain':
      electro_weak -= 1
      if electro_y <= 210:
         electro_y += 5
      electro_w = 30
      electro_h = 30
    elif electro_weak > 0 and electro_current == 'rain':
      electro_weak -= 1
      electro_x = 235
      electro_y = 120
      electro_w = 30
      electro_h = 30
    if electro_cooldown != 0:
      electro_cooldown -= 1
    if electro_weak == 0 and electro_cooldown <= 50:
      electro_x = electro_savex
      electro_y = 150
      electro_w = 80
      electro_h = 80
    pygame.draw.rect(window, (174, 0, 223), (electro_x,electro_y,electro_w,electro_h)) 
    if electro_cooldown>100 and electro_direction==0 and electro_current=='drill':
      window.blit(drill_R,(electro_x+60,electro_y-20))
    if electro_cooldown>100 and electro_direction==1 and electro_current=="drill":
      window.blit(drill_L,(electro_x-100,electro_y-20))
    #Health Bars
    pygame.draw.ellipse(window,(blast_charge),(5,140,25,25))
    pygame.draw.rect(window,(0,0,0),(50,10,400,15))
    pygame.draw.rect(window,(241, 56, 94),(50,10,electro_health,15))
    pygame.draw.rect(window, (0,0,0),(10,30,10,100))
    pygame.draw.rect(window,(0,200,0),(10,player_healthbar_y,10,player_health))
    pygame.display.update()
  if player_health <= 0:
    return 0
  elif electro_health <= 0:
    return 1
  else:
    return 2
  
#End Game
def end_screen(status):
  pygame.time.delay(300)
  end_menu = True
  if status == 0:
    window.blit(liyue,(-100,-60))
    loss_status = 0
    while end_menu == True:
      pygame.time.delay(25)
      for event in pygame.event.get():
        if event.type == QUIT:
          pygame.quit()
          sys.exit()
      if loss_status == 0:
        pygame.draw.rect(window, (203, 203, 36), (100,190,100,25))
        pygame.draw.rect(window, (137, 116, 0), (300,190,100,25))
      elif loss_status == 1:
        pygame.draw.rect(window, (137, 116, 0), (100,190,100,25))
        pygame.draw.rect(window, (203, 203, 36), (300,190,100,25))
      window.blit(play_a,(100,190))
      window.blit(back_to,(300,190))
      window.blit(defeat,(125,25))
      keys = pygame.key.get_pressed()
      if keys[pygame.K_d] and loss_status == 0:
        loss_status = 1
      if keys[pygame.K_a] and loss_status == 1:
        loss_status = 0
      if keys[pygame.K_SPACE] and loss_status == 0:
        return True
      if keys[pygame.K_SPACE] and loss_status == 1:
        return False
      pygame.display.update() 
  if status == 1:
    window.blit(sumeru,(-100,-60))
    loss_status = 0
    while end_menu == True:
      pygame.time.delay(25)
      for event in pygame.event.get():
        if event.type == QUIT:
          pygame.quit()
          sys.exit()
      if loss_status == 0:
        pygame.draw.rect(window, (28, 221, 70), (100,190,100,25))
        pygame.draw.rect(window, (13, 98, 23), (300,190,100,25))
      elif loss_status == 1:
        pygame.draw.rect(window, (13, 98, 23), (100,190,100,25))
        pygame.draw.rect(window, (28, 221, 70), (300,190,100,25))
      window.blit(play_a,(100,190))
      window.blit(back_to,(300,190))
      window.blit(victory,(125,25))
      keys = pygame.key.get_pressed()
      if keys[pygame.K_d] and loss_status == 0:
        loss_status = 1
      if keys[pygame.K_a] and loss_status == 1:
        loss_status = 0
      if keys[pygame.K_SPACE] and loss_status == 0:
        return True
      if keys[pygame.K_SPACE] and loss_status == 1:
        return False
      pygame.display.update() 
      
#Main Loop
while run_game == True:
  if restart_game == False:
    menu_load(first_time)
    first_time = False
  status = main_game()
  restart_game = end_screen(status)