To launch this file, you first require a version of python and pygame
To make sure you have these, in your CMD use:

"python3 --version" to see if you have an installation of python. If not go to: https://www.python.org/downloads/

"pip3 install pygame" to install pygame as well

Navigate in the terminal to the location of installation and run "python main.py"
